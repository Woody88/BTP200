class Fraction {

int num, denom;

public:
	void set(int, int);
	void simplify();
	int gcd(int, int);
	int numerator() const;
	int denominator() const;
	void display();
};


