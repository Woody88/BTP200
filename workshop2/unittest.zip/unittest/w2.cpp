#include <iostream>
 using namespace std;
 #include "Fraction.h"

 int unitTests(Fraction* f) {

     cout << "Fraction Simplifier Tests" << endl; 
     cout << "=========================" << endl;

     // fill in code for unit tests
     
     f->set(4,16);
	
}

 int main() {
     Fraction fraction;
     bool passed;

     passed = unitTests(&fraction);

     if (passed)
         cout << "Passed All Tests" << endl;
     else
         cout << "Failed Tests" << endl;
 }
