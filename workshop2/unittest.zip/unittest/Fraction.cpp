#include <iostream>
#include "Fraction.h"
void Fraction::set(int x, int y){	

	this->num = x;
	this->denom = y;
	simplify();
}

void Fraction::simplify(){

        int a, b, result;
       		
        if(this->num  == 0){
                set(0, 0);
        }
        else if (this->denom  == 0) {
                set(0,0);
        }

        if (this->num != 0 && this->denom != 0){
                a = this->num;
		b = this->denom;
		/*result = gcd(a, b);*/
                set(a/result, b/result);
        }
	
}


int Fraction::gcd(int k, int l){

        int a, b, c, d;
        a = k;
        b = l;
        c = a/b;
        d = a%b;

        if(d != 0){
                gcd(b, d);
        }
        else {
                return b;
        }

}


void Fraction::display(){
	int nume, denomi;
	nume = numerator();
	denomi = denominator();

        std::cout << nume << "/" << denomi;
}

int Fraction::numerator() const {
	return num;
}

int Fraction::denominator() const {
	return denom;
}
